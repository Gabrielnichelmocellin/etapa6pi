package biblioteca.repository;

import biblioteca.model.Livro;
import java.util.List;

public interface LivroRepository {
    void salvar(Livro livro);
    List<Livro> listarTodos();
    Livro buscarPorTitulo(String titulo);
    int buscarIdPorTitulo(String titulo) throws Exception;
    void atualizarDisponibilidade(String titulo, boolean disponivel);
}