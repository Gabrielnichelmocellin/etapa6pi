package biblioteca.repository;

import biblioteca.model.Usuario;
import java.util.List;

public interface UsuarioRepository {
    void salvar(Usuario usuario);
    List<Usuario> listarTodos();
    Usuario buscarPorCpf(String cpf);
    int buscarIdPorCpf(String cpf) throws Exception;
}