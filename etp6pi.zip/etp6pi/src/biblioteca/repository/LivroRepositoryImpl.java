package biblioteca.repository;

import biblioteca.model.Livro;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivroRepositoryImpl implements LivroRepository {
    
    @Override
    public void salvar(Livro livro) {
        String sql = "INSERT INTO livro (titulo, autor, disponivel) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, livro.getTitulo());
            stmt.setString(2, livro.getAutor());
            stmt.setBoolean(3, livro.isDisponivel());
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar livro: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Livro> listarTodos() {
        List<Livro> livros = new ArrayList<>();
        String sql = "SELECT * FROM livro";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Livro l = new Livro(
                    rs.getString("titulo"),
                    rs.getString("autor")
                );
                l.setId(rs.getInt("id"));
                l.setDisponivel(rs.getBoolean("disponivel"));
                livros.add(l);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar livros: " + e.getMessage(), e);
        }
        return livros;
    }

    @Override
    public Livro buscarPorTitulo(String titulo) {
        String sql = "SELECT * FROM livro WHERE titulo = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, titulo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Livro livro = new Livro(
                        rs.getString("titulo"),
                        rs.getString("autor")
                    );
                    livro.setId(rs.getInt("id"));
                    livro.setDisponivel(rs.getBoolean("disponivel"));
                    return livro;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar livro: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public int buscarIdPorTitulo(String titulo) throws Exception {
        String sql = "SELECT id FROM livro WHERE titulo = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, titulo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        }
        throw new Exception("Livro não encontrado com título: " + titulo);
    }

    @Override
    public void atualizarDisponibilidade(String titulo, boolean disponivel) {
        String sql = "UPDATE livro SET disponivel = ? WHERE titulo = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setBoolean(1, disponivel);
            stmt.setString(2, titulo);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar disponibilidade: " + e.getMessage(), e);
        }
    }
}