package biblioteca.main;

import biblioteca.model.Usuario;
import biblioteca.model.Livro;
import biblioteca.repository.UsuarioRepository;
import biblioteca.repository.LivroRepository;
import biblioteca.repository.UsuarioRepositoryImpl;
import biblioteca.repository.LivroRepositoryImpl;
import biblioteca.service.BibliotecaService;
import biblioteca.service.BibliotecaServiceImpl;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== TESTE DO SISTEMA BIBLIOTECA ===");
        
        try {
            UsuarioRepository usuarioRepo = new UsuarioRepositoryImpl();
            LivroRepository livroRepo = new LivroRepositoryImpl();
            BibliotecaService bibliotecaService = new BibliotecaServiceImpl(usuarioRepo, livroRepo);
          
            Usuario usuario = new Usuario("João Silva", "123.456.789-00", "cliente", "joao@email.com");
            bibliotecaService.cadastrarUsuario(usuario);
            System.out.println(" Usuário cadastrado: " + usuario.getNome());
      
            Livro livro = new Livro("Dom Casmurro", "Machado de Assis");
            bibliotecaService.cadastrarLivro(livro);
            System.out.println(" Livro cadastrado: " + livro.getTitulo());
 
            var usuarios = usuarioRepo.listarTodos();
            var livros = livroRepo.listarTodos();
            
            System.out.println("\nRESUMO:");
            System.out.println("Usuários cadastrados: " + usuarios.size());
            System.out.println("Livros cadastrados: " + livros.size());
            
            System.out.println("\nTODOS OS TESTES PASSARAM!");
            
        } catch (Exception e) {
            System.err.println(" Erro durante teste: " + e.getMessage());
            e.printStackTrace();
        }
    }
}