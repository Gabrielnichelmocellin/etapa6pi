package biblioteca.service;

import biblioteca.model.Usuario;
import biblioteca.model.Livro;
import biblioteca.repository.UsuarioRepository;
import biblioteca.repository.LivroRepository;

public class BibliotecaServiceImpl implements BibliotecaService {
    private final UsuarioService usuarioService;
    private final LivroService livroService;
    private final EmprestimoService emprestimoService;
    
    public BibliotecaServiceImpl(UsuarioRepository usuarioRepo, LivroRepository livroRepo) {
        this.usuarioService = new UsuarioService(usuarioRepo);
        this.livroService = new LivroService(livroRepo);
        this.emprestimoService = new EmprestimoService(usuarioRepo, livroRepo);
    }
    
    @Override
    public void cadastrarUsuario(Usuario usuario) {
        usuarioService.cadastrarUsuario(usuario);
    }
    
    @Override
    public void cadastrarLivro(Livro livro) {
        livroService.cadastrarLivro(livro);
    }
    
    @Override
    public void registrarEmprestimo(String cpfUsuario, String tituloLivro) {
        emprestimoService.registrarEmprestimo(cpfUsuario, tituloLivro);
    }
}