package biblioteca.service;

import biblioteca.model.Usuario;
import biblioteca.repository.UsuarioRepository;
import java.util.List;

public class UsuarioService {
    private final UsuarioRepository usuarioRepository;
    
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }
    
    public void cadastrarUsuario(Usuario usuario) {
        validarUsuario(usuario);
        usuarioRepository.salvar(usuario);
    }
    
    public List<Usuario> listarUsuarios() {
        return usuarioRepository.listarTodos();
    }
    
    public Usuario buscarUsuarioPorCpf(String cpf) {
        return usuarioRepository.buscarPorCpf(cpf);
    }
    
    private void validarUsuario(Usuario usuario) {
        if (usuario.getNome() == null || usuario.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do usuário é obrigatório");
        }
        if (usuario.getCpf() == null || usuario.getCpf().trim().isEmpty()) {
            throw new IllegalArgumentException("CPF do usuário é obrigatório");
        }
    }
}