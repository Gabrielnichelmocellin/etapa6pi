package biblioteca.service;

import biblioteca.model.Livro;
import biblioteca.repository.LivroRepository;
import java.util.List;

public class LivroService {
    private final LivroRepository livroRepository;
    
    public LivroService(LivroRepository livroRepository) {
        this.livroRepository = livroRepository;
    }
    
    public void cadastrarLivro(Livro livro) {
        validarLivro(livro);
        livroRepository.salvar(livro);
    }
    
    public List<Livro> listarLivros() {
        return livroRepository.listarTodos();
    }
    
    public Livro buscarLivroPorTitulo(String titulo) {
        return livroRepository.buscarPorTitulo(titulo);
    }
    
    public void atualizarDisponibilidade(String titulo, boolean disponivel) {
        livroRepository.atualizarDisponibilidade(titulo, disponivel);
    }
    
    private void validarLivro(Livro livro) {
        if (livro.getTitulo() == null || livro.getTitulo().trim().isEmpty()) {
            throw new IllegalArgumentException("Título do livro é obrigatório");
        }
        if (livro.getAutor() == null || livro.getAutor().trim().isEmpty()) {
            throw new IllegalArgumentException("Autor do livro é obrigatório");
        }
    }
}