package biblioteca.service;

import biblioteca.model.Usuario;
import biblioteca.model.Livro;

public interface BibliotecaService {
    void cadastrarUsuario(Usuario usuario);
    void cadastrarLivro(Livro livro);
    void registrarEmprestimo(String cpfUsuario, String tituloLivro);
}