package biblioteca.service;

import biblioteca.repository.UsuarioRepository;
import biblioteca.repository.LivroRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Date;

public class EmprestimoService {
    private final UsuarioRepository usuarioRepository;
    private final LivroRepository livroRepository;
    
    public EmprestimoService(UsuarioRepository usuarioRepository, LivroRepository livroRepository) {
        this.usuarioRepository = usuarioRepository;
        this.livroRepository = livroRepository;
    }
    
    public void registrarEmprestimo(String cpfUsuario, String tituloLivro) {
        validarEmprestimo(cpfUsuario, tituloLivro);
        
        try (Connection conn = biblioteca.repository.Conexao.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                String sqlEmprestimo = "INSERT INTO emprestimo (id_usuario, id_livro, data_emprestimo) VALUES (?, ?, ?)";
                try (PreparedStatement stmtEmprestimo = conn.prepareStatement(sqlEmprestimo)) {
                    stmtEmprestimo.setInt(1, usuarioRepository.buscarIdPorCpf(cpfUsuario));
                    stmtEmprestimo.setInt(2, livroRepository.buscarIdPorTitulo(tituloLivro));
                    stmtEmprestimo.setDate(3, new Date(System.currentTimeMillis()));
                    stmtEmprestimo.executeUpdate();
                }
                
                livroRepository.atualizarDisponibilidade(tituloLivro, false);
                
                conn.commit();
                
            } catch (Exception e) {
                conn.rollback();
                throw new RuntimeException("Erro ao registrar empréstimo: " + e.getMessage(), e);
            }
            
        } catch (Exception e) {
            throw new RuntimeException("Erro de conexão: " + e.getMessage(), e);
        }
    }
    
    private void validarEmprestimo(String cpfUsuario, String tituloLivro) {
        var usuario = usuarioRepository.buscarPorCpf(cpfUsuario);
        var livro = livroRepository.buscarPorTitulo(tituloLivro);
        
        if (usuario == null) {
            throw new IllegalArgumentException("Usuário não encontrado com CPF: " + cpfUsuario);
        }
        if (livro == null) {
            throw new IllegalArgumentException("Livro não encontrado com título: " + tituloLivro);
        }
        if (!livro.isDisponivel()) {
            throw new IllegalStateException("Livro já está emprestado: " + tituloLivro);
        }
    }
}